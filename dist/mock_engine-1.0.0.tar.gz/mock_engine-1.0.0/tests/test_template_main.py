import json
from mock_engine.core.template_engine import TemplateEngine

def main():
    """直接执行代码测试模板引擎"""
    # 初始化模板引擎，开启 debug 模式
    engine = TemplateEngine(debug=True)

    # 注册自定义方法
    @engine.register_method()
    def format_greeting(name):
        return f"你好，{name}！"

    # 创建模板（使用@变量形式）
    template = {
        "greeting": "@format_greeting(name)",
        "age": "@age",
        "faker_name": "@faker.name()",
        "nested": {
            "user": {
                "name": "@name",
                "email": "@faker.email()"
            }
        },
        # 测试请求头访问
        "headers": {
            "content_type": "@request_header.content-type",
            "user_agent": "@request_header.user-agent",
            "all_headers": "@request_header"
        },
        # 测试请求体访问
        "body": {
            "username": "@request_body.username",
            "password": "@request_body.password",
            "profile": {
                "age": "@request_body.profile.age",
                "address": "@request_body.profile.address"
            },
            "all_body": "@request_body"
        }
    }

    # 创建请求数据
    request = {
        "name": "张三",
        "age": 25,
        "headers": {
            "content-type": "application/json",
            "user-agent": "Mozilla/5.0",
            "authorization": "Bearer token123"
        },
        "body": {
            "username": "zhangsan",
            "password": "123456",
            "profile": {
                "age": 25,
                "address": "北京市朝阳区"
            }
        }
    }

    # 生成数据
    result, debug = engine.generate(template, request)
    
    # 打印结果
    print("\n=== 模板渲染结果 ===")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    
    print("\n=== 调试输出 ===")
    for msg in debug:
        print(f"- {msg}")

if __name__ == "__main__":
    main() 